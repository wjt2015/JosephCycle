/*
ubuntu 14.04
gcc4.8.4
//----
DeleteData.c
gcc -g3 DeleteData.c -o gDeleteData_exe
./gDeleteData_exe
gdb gDeleteData_exe
//-----
*/
#include<stdio.h>
#include<stdlib.h>
//----------
#define _NCOUNT1_ 2
#define _NCOUNT2_ 3
//----------
/*
约瑟夫环；
有n个元素构成一个环，元素ID分别是0，1，2，....，n-1。
从元素ID=0开始，报数1，元素ID=1报数2，....，删除报数为m的元素，
从下一个元素开始从1报数，逐次增1，删除报数为m的元素，循环进行，直到只剩下一个元素，
最后剩下的元素成为优胜者。给出n个元素和正整数m，找出按上述方法删除后的优胜者ID。
时间复杂度:T(n)=O(n^2);
空间复杂度:S(n)=O(1);
*/
void GetJosephWinnerID(const int n,const int m,int* pwinnerID)
{/*n>=1;m>=1;pwinnerID!=NULL*/
	int k=0;
	if(n==1)
	{
		*pwinnerID=0;
	}
	else/*n>=2*/
	{
		k=(m-1)%n;
		GetJosephWinnerID(n-1,m,pwinnerID);
		*pwinnerID=(*pwinnerID+k+1)%n;
	}
}
//---------
/*
变异的约瑟夫环1;
有n个元素构成一个环，元素ID分别是0，1，2，....，n-1。
从元素ID=0开始，报数1，元素ID=1报数2，....，删除报数为m=_NCOUNT1_的元素，
从下一个元素开始从1报数，逐次增1，删除报数为m=_NCOUNT2_的元素，循环进行，直到只剩下一个元素，
最后剩下的元素成为优胜者。给出n个元素和不同的两个正整数m，找出按上述方法删除后的优胜者ID。
时间复杂度:T(n)=O(n^2);
空间复杂度:S(n)=O(1);
*/
void GetJosephWinnerID1(const int n,const int m,int* pwinnerID)
{/*n>=1;m>=1;pwinnerID!=NULL*/
	int k=0;
	if(n==1)
		*pwinnerID=0;
	else/*n>=2*/
	{
		k=(m-1)%n;
		GetJosephWinnerID1(n-1,m==_NCOUNT1_?_NCOUNT2_:_NCOUNT1_,pwinnerID);
		*pwinnerID=(*pwinnerID+k+1)%n;
	}
}
//------
/*
变异的约瑟夫环2;
有n个元素构成一个环，元素ID分别是0，1，2，....，n-1。
从元素ID=0开始，报数1，元素ID=1报数2，....，删除报数为m=_NCOUNT1_的元素，
从下一个元素开始从1报数，逐次增1，删除报数为m=_NCOUNT2_的元素，循环进行，直到剩下的元素个数不超过nLeft，
最后剩下的元素都成为优胜者。给出n个元素和不同的两个正整数m，以及正整数nLeft，找出按上述方法删除后的所有的优胜者ID。
时间复杂度:T(n)=O(n^2);
空间复杂度:S(n)=O(n);
*/
void GetJosephWinnerID2(const int n,const int m,int* pwinnerID_arr,const int nLeft)
{/*n>=1;m>=1;pwinnerID_arr!=NULL;nLeft>=1*/
	int i=0,k=0;
	if(n<=nLeft)
	{
		for(i=0;i<n;i++)
			pwinnerID_arr[i]=i;
		if(i<nLeft)
			pwinnerID_arr[i]=-1;
	}
	else/*n>nLeft*/
	{
		k=(m-1)%n;
		GetJosephWinnerID2(n-1,m==_NCOUNT1_?_NCOUNT2_:_NCOUNT1_,pwinnerID_arr,nLeft);
		for(i=0;i<nLeft&&pwinnerID_arr[i]>=0;i++)
			pwinnerID_arr[i]=(pwinnerID_arr[i]+k+1)%n;
	}
}
//-----------------
/*
横排元素的优胜者；
有n个元素排成一条横线，元素ID分别是0，1，2，....，n-1。
从元素ID=0开始，报数1，元素ID=1报数2，....，删除报数为m=_NCOUNT1_的元素，继续如此操作，直到本队列最后一个元素；
若元素个数不超过nLeft，剩下的元素都成为优胜者。
从元素ID=0开始，报数1，元素ID=1报数2，....，删除报数为m=_NCOUNT2_的元素，继续如此操作，直到本队列最后一个元素；
若元素个数不超过nLeft，剩下的元素都成为优胜者。
上述两种循环交替进行，找出最终的优胜者。
给出n个元素和不同的两个正整数m，以及正整数nLeft，找出按上述方法删除后的所有的优胜者ID。
时间复杂度:T(n)=O(n^2);
空间复杂度:S(n)=O(n);
*/
void LineWinner(const int n,const int m,int* pwinnerID_arr,const int nLeft)
{/*n>=1;m>=2;pwinnerID_arr!=NULL;nLeft>=1*/
	int i=0;
	if(n<=nLeft)
	{
		for(i=0;i<n;i++)
			pwinnerID_arr[i]=i;
		if(i<nLeft)
			pwinnerID_arr[i]=-1;/*结束标志*/
	}
	else/*n>nLeft*/
	{
		const int t=m-1;
		LineWinner(n-n/m,m,pwinnerID_arr,nLeft);
		for(i=0;i<nLeft&&pwinnerID_arr[i]>=0;i++)
			pwinnerID_arr[i]=pwinnerID_arr[i]+pwinnerID_arr[i]/t;
	}
}
//---------
int main()
{
	int n=1,m=2,nLeft=1,i=0;
	int winnerID=0;
	int* pwinnerID_arr=NULL;
	printf("\t请输入n,m,nLeft:");
	scanf("%d %d %d",&n,&m,&nLeft);
	printf("\n");
	if(n<1||m<2||nLeft<1)
	{
		printf("\t输入数据非法!!!\n");
		exit(1);
	}
	pwinnerID_arr=(int*)calloc(nLeft,sizeof(int));
	//-------
	GetJosephWinnerID(n,m,&winnerID);
	printf("\t约瑟夫环，优胜者ID=%d\n\n",winnerID);
	//-----
	m=_NCOUNT1_;
	GetJosephWinnerID1(n,m,&winnerID);
	printf("\t约瑟夫环1，优胜者ID=%d\n\n",winnerID);
	//--------
	m=_NCOUNT1_;
	GetJosephWinnerID2(n,m,pwinnerID_arr,nLeft);
	printf("\t约瑟夫环2，优胜者ID列表:\n");
	for(i=0;i<nLeft&&pwinnerID_arr[i]>=0;i++)
		printf("\twinnerID_arr[%d]=%d\n",i,pwinnerID_arr[i]);
	printf("\n");
	//-----------
	m=_NCOUNT1_;
	LineWinner(n,m,pwinnerID_arr,nLeft);
	printf("\t横排元素的优胜者ID列表:\n");
	for(i=0;i<nLeft&&pwinnerID_arr[i]>=0;i++)
		printf("\twinnerID_arr[%d]=%d\n",i,pwinnerID_arr[i]);
	printf("\n");
	//-------
	free(pwinnerID_arr);
	return 0;
}
//----------------




